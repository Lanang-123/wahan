<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($data->name); ?> | <?php echo e($data->type); ?> | <?php echo e($data->created_at); ?></title>
    <style>
          
        .code-3 {
            position: absolute;
            z-index: 1;
            top: 45px;
            right: -10px;
            transform: rotate(90deg);
            font-size: 18px;
        }    
        .qr-3 {
            width: 100px;
            height: 100px;
            position: absolute;
            z-index: 1;
            top: 15px;
            right: 25px;
        } 
        .wrapper {
            width: 3000px;
            position: relative;
            /* border: 1px solid red; */
        }   
        .tic-wrapp {
            /* border: 1px solid #999; */
            width: 1475px;
            float: left;
            margin: 0 10px;
            position: relative;
            /* margin-bottom: 8px; */
        }
        .img {
            vertical-align: middle;
            /* width: 795px; */
            width: 1330px;
            position: relative;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <?php if($items AND count($items) > 0): ?>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <div class="tic-wrapp">
                    <?php if($item->ticket_image): ?>
                        <img class="img" src="<?php echo e($item->ticket_image); ?>"/>
                    <?php else: ?>
                        <img class="img" src="<?php echo e(asset('/assets/images/bracelet-ticket.png')); ?>"/>
                    <?php endif; ?>
                    
                    
                    
                    
                    
                    <div class="code-3">
                        <div><?php echo e($item->code); ?></div>
                    </div>
                    <div class="qr-3">
                        <?php echo QrCode::size(90)->generate($item->code); ?>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</body>
</html><?php /**PATH D:\xampp3\htdocs\PASSS\wahana\resources\views/pages/prints/gelang-download.blade.php ENDPATH**/ ?>