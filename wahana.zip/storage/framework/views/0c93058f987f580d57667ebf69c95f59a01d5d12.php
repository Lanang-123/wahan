<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <form class="form" action="<?php echo e(route('accepted-handover', ['id' => $data['id']])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="card-title mb-3">Form serah terima <?php echo e($data->type); ?></div>
                        <div class="separator-breadcrumb border-top"></div>
                        <div class="row mb-4">
                            <div class="col-md-12 text-20">
                                <div>Total <?php echo e($data->type); ?>: <?php echo e($data->total); ?></div>
                            </div>
                        </div>
                        <div class="row">
                            <?php if($items AND count($items) > 0): ?>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-1 form-group mb-3 text-center">
                                        <?php echo QrCode::size(50)->generate($item->code); ?>

                                        <div><?php echo e($item->code); ?></div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-danger">Terima</button>
                        <a href="<?php echo e(route('handover-list')); ?>" class="btn btn-outline-light">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp3\htdocs\PASSS\wahana\resources\views/pages/handovers/form.blade.php ENDPATH**/ ?>