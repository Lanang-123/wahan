<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
    <style>
        .wrapper {
            /* border: 1px solid red; */
            width: 250px;
            font-size: 12px;
        }    
        .left {
            text-align: left;
        }    
        .center {
            text-align: center;
        }    
        .right {
            text-align: right;
        }   
        .font-16 {
            font-size: 16px;
        } 
        .bold {
            font-weight: bold;
        }
    </style>
    <script>

        function cetak() {
            window.print();
        }
    </script>
</head>
<body>
    <div class="wrapper">
        <table width="100%" style="border-bottom: 1px solid #aaa">
            <tr>
                <td width="60">
                    <?php echo QrCode::size(50)->generate($item->order_number); ?></td>

                <td>
                    <div class="center font-16 bold" style="margin-bottom: 5px">
                        <div> Diamond</div>
                    </div>
                    <div class="center"><?php echo e($item->order_number); ?></div>
                </td>
            </tr>
            <tr>
                <td colspan="2">Tanggal <?php echo e($item->created_at_display); ?></td>
            </tr>
        </table>
        <table width="100%">
            <tr class="bold">
                <td>Item</td>
                <td>Code</td>
                <td style="text-align: right">Harga</td>
            </tr>
            <?php if($item->items AND count($item->items) > 0): ?>
                <?php $__currentLoopData = $item->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($orderItem->product_type); ?></td>
                        <td><?php echo e($orderItem->code); ?></td>
                        <td style="text-align: right"><?php echo e($orderItem->price_display); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </table>
        <table width="100%" style="border-top: 1px solid #aaa">
            <tr class="bold" >
                <td colspan="2">Total</td>
                <td style="text-align: right"><?php echo e($item->total_price_display); ?></td>
            </tr>
        </table>
        <div class="center bold">Terima Kasih</div>
        <div style="margin-top: 10px; text-align:center">
            <?php if(\Request::get('from') == 'list'): ?>
                <a href="<?php echo e(route('order-list')); ?>">Kembali</a>
            <?php elseif(\Request::get('from') == 'with-parking'): ?>
                <a href="<?php echo e(route('new-order-with-parking')); ?>">Kembali</a>
            <?php else: ?> 
                <a href="<?php echo e(route('new-order')); ?>">Kembali</a>
            <?php endif; ?>
            <button onclick="cetak()">Print</button>
        </div>
    </div>
</body>
</html>



<?php /**PATH /home/u827505187/domains/tiketparkirdiamond.com/wahana/resources/views/pages/orders/order-print.blade.php ENDPATH**/ ?>