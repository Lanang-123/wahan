<?php $__env->startSection('page-css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/styles/vendor/sweetalert2.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div>
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>

                <?php if($message = Session::get('error')): ?>
                    <div class="alert alert-danger alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>
            </div>
            <form action="<?php echo e(route('form-transfer-fee')); ?>" method="post">
                <?php echo csrf_field(); ?>

                <div class="card text-left mb-4">
                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-6"><h4>Transfer Fee Guide</h4></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <label>Nomor Order</label>
                                <div class="input-group">
                                    <input type="text" name="order_number" value="" class="form-control js-init-focus" placeholder="Masukkan nomor order">
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </form>
            <form action="<?php echo e(route('transfer-fee-list')); ?>" method="get">
                <div class="card text-left">
                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-6"><h4>Daftar Transfer Fee Guide</h4></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <h5><i class="i-Filter-2 mr-2"></i>Filter</h5>
                            </div>
                            <div class="row col-md-12">
                                <div class="col-md-4 mb-3">
                                    <label>Nomor Order</label>
                                    <div class="input-group">
                                        <select class="js-autocomplete form-control" name="order_number" data-selected="<?php echo e($order_number); ?>" value="<?php echo e($order_number); ?>">
                                            <option value="">-- Semua Order --</option>
                                            <?php $__currentLoopData = $orderFilter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemFilter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($itemFilter->order_number); ?>" <?php echo e(($itemFilter->order_number == $order_number)? 'selected': ''); ?>><?php echo e($itemFilter->order_number); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2 mb-3 d-flex align-items-end">
                                    <button type="submit" class="btn btn-danger" >Filter</button>
                                </div>
                            </div>
                        </div>

                        <?php if(count($data) > 0): ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Nomor Order</th>
                                            <th scope="col">Total Order </th>
                                            <th scope="col">Total Masuk Wahana </th>
                                            <th scope="col">Fee Masuk Wahana</th>
                                            <th scope="col">Fee Masuk Objek</th>
                                            <th scope="col">Total Fee</th>
                                            <th scope="col">Guide</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(count($data) == 1): ?>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <th scope="row"><?php echo e($data->firstItem() + $key); ?></th>
                                                    <td><?php echo e($item->order_number); ?></td>
                                                    <td><?php echo e($item->total_price_display); ?></td>
                                                    <td><?php echo e($item->total_price_checkin_ride_display); ?></td>
                                                    <td><?php echo e($item->guide_fee_checkin_ride_display); ?></td>
                                                    <td><?php echo e($item->guide_fee_checkin_object_display); ?></td>
                                                    <td><?php echo e($item->total_guide_fee_display); ?></td>
                                                    <td><?php echo e(($item->use_guide) ? 'Ya' : 'Tidak'); ?></td>
                                                    <td width="80">
                                                        <a href="<?php echo e(route('edit-transfer-fee', ['id' => $item->id])); ?>" class="text-success mr-2" data-toggle="tooltip" data-placement="bottom" title="Transfer">
                                                            <i class="text-24 h5 nav-icon i-Credit-Card-3 "></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-md-12 mt-5 text-center">
                                <?php echo e($data->links()); ?>

                            </div>
                        <?php else: ?> 
                            <div class="py-4">
                                <div class="text-center mb-2">Tidak ada hasil yang ditemukan</div>
                                
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
<script src="<?php echo e(asset('assets/js/tooltip.script.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/vendor/sweetalert2.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp3\htdocs\PASSS\wahana\resources\views/pages/transferFee/index.blade.php ENDPATH**/ ?>