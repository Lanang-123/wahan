<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Diamond</title>
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,400i,600,700,800,900" rel="stylesheet">
    <link rel="shortcut icon" href="<?php echo e(asset('/favicon.ico')); ?>" type="image/x-icon">
    <link rel="icon" href="<?php echo e(asset('/favicon.ico')); ?>" type="image/x-icon">
    <?php echo $__env->yieldContent('before-css'); ?>
    
    <link id="gull-theme" rel="stylesheet" href="<?php echo e(asset('assets/styles/css/themes/lite-blue.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/vendor/perfect-scrollbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/vendor/sweetalert2.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/select2.min.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <?php echo $__env->yieldContent('page-css'); ?>
    <style>
        .select2-container {
            width: 100% !important;
        }
        
    </style>
</head>

<body class="text-left">
    

    <!-- Pre Loader Strat  -->
    <!-- <div class='loadscreen' id="preloader">
        <div class="loader spinner-bubble spinner-bubble-primary">
        </div>
    </div> -->
    <!-- Pre Loader end  -->

    <!-- ============ Large SIdebar Layout start ============= -->

    <div class="app-admin-wrap layout-sidebar-large clearfix">
        <?php echo $__env->make('layouts.header-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- ============ end of header menu ============= -->

        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- ============ end of left sidebar ============= -->

        <!-- ============ Body content start ============= -->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <div class="main-content">
                <?php echo $__env->yieldContent('main-content'); ?>
            </div>
            
        </div>
        <!-- ============ Body content End ============= -->
    </div>
    <!--=============== End app-admin-wrap ================-->


    <script src="<?php echo e(asset('assets/js/common-bundle-script.js')); ?>"></script>
    
    <?php echo $__env->yieldContent('page-js'); ?>

    
    
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/sidebar.large.script.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/customizer.script.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/tooltip.script.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/sweetalert2.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    <script src="<?php echo e(asset('js/autoNumeric.min.js')); ?>"></script>

    
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/page.js')); ?>"></script>
    

    <?php echo $__env->yieldContent('bottom-js'); ?>
    <script src="http://localhost:35729/livereload.js"></script>
</body>

</html>
<?php /**PATH D:\xampp3\htdocs\PASSS\wahana\resources\views/layouts/master.blade.php ENDPATH**/ ?>