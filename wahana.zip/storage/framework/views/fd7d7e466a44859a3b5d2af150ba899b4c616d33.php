<?php $__env->startSection('page-css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/styles/vendor/sweetalert2.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card text-left">
                <div class="card-body">
					<div class="row mb-3">
                        <div class="col-md-6"><h4>Jenis Tiket</h4></div>
                        <?php if(count($data) > 0): ?>
                            <div class="col-md-6 text-right">
                                <a href="<?php echo e(route('new-ticket-type')); ?>" class="btn btn-sm btn-info">
                                    <i class="h6 nav-icon i-Add mr-1 "></i>
                                    Tambah
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div>
                        <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success alert-block">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong><?php echo e($message); ?></strong>
                            </div>
                        <?php endif; ?>

                        <?php if($message = Session::get('error')): ?>
                            <div class="alert alert-danger alert-block">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong><?php echo e($message); ?></strong>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php if(count($data) > 0): ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Nama</th>
                                        <th scope="col">Harga</th>
                                        <th scope="col">Fee</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Desain</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($key + 1); ?></th>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->price_display); ?></td>
                                            <td><?php echo e($item->fee_display); ?></td>
                                            <td>
                                                <?php if($item->is_active): ?>
                                                    <span class="badge badge-success">Aktif</span>
                                                <?php else: ?>
                                                    <span class="badge badge-danger">Tidak aktif</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <image src="<?php echo e($item->image); ?>" width="220"/>
                                            </td>
                                            <td width="80">
                                                <a href="<?php echo e(route('edit-ticket-type', ['slug' => $item->slug])); ?>" class="text-warning mr-2" data-toggle="tooltip" data-placement="bottom" title="Edit">
                                                    <i class="h5 nav-icon i-Pen-2 font-weight-bold"></i>
                                                </a>
                                                <a href="<?php echo e(route('delete-ticket-type', ['slug' => $item->slug])); ?>" class="text-danger mr-2 alert-confirm" data-toggle="tooltip" data-placement="bottom" id="" title="Delete">
                                                    <i class="h5 nav-icon i-Close-Window font-weight-bold"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?> 
                        <div class="py-4">
                            <div class="text-center mb-2">Tidak ada hasil yang ditemukan</div>
                            <div class="text-center">
                                <a href="<?php echo e(route('new-ticket-type')); ?>" class="btn btn-sm btn-info">
                                    <i class="h6 nav-icon i-Add mr-1 "></i>
                                    Tambah
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
<script src="<?php echo e(asset('assets/js/tooltip.script.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/vendor/sweetalert2.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Job\DMedia\wahana\resources\views/pages/ticketTypes/index.blade.php ENDPATH**/ ?>