<?php $__env->startSection('page-css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/styles/vendor/sweetalert2.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card text-left">
                <form action="<?php echo e(route('report-fee-transfers')); ?>" method="get">
                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <h5><i class="i-Filter-2 mr-2"></i>Filter</h5>
                            </div>
                            <div class="row col-md-12">
                                <div class="col-md-3 mb-3">
                                    <label>Dari tanggal</label>
                                    <div class="input-group">
                                        <input name="startDate" value="<?php echo e(!empty(old('startDate')) ? old('startDate') : $startDate); ?>" class="picker2 form-control form-control" placeholder="yyyy-mm-dd" >
                                        <div class="input-group-append">
                                            <button class="btn btn-info"  type="button">
                                                <i class="icon-regular i-Calendar-4"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label>Sampai tanggal</label>
                                    <div class="input-group">
                                        <input name="endDate" value="<?php echo e(!empty(old('endDate')) ? old('endDate') : $endDate); ?>" class="picker2 form-control form-control" placeholder="yyyy-mm-dd" >
                                        <div class="input-group-append">
                                            <button class="btn btn-info"  type="button">
                                                <i class="icon-regular i-Calendar-4"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Guide</label>
                                    <div class="input-group">
                                        <select class="js-autocomplete form-control" name="guide_id" data-selected="<?php echo e($guide_id); ?>" value="<?php echo e($guide_id); ?>">
                                            <option value="">-- Semua guide --</option>
                                            <?php $__currentLoopData = $guides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>" <?php echo e(($item->id == $guide_id)? 'selected': ''); ?>><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2 mb-3 d-flex align-items-end">
                                    <button type="submit" class="btn btn-danger" >Filter</button>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6"><h4>Laporan Transfer Fee Guide</h4></div>
                        </div>
                        <div>
                            <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>

                            <?php if($message = Session::get('error')): ?>
                                <div class="alert alert-danger alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php if(count($data) > 0): ?>
                            <div class="d-md-flex mb-3 justify-content-between">
                                <a href="<?php echo e(route('report-fee-transfers', ['download' => true, 'startDate' => $startDate, 'endDate' => $endDate, 'guide_id' => $guide_id])); ?>" class="btn btn-success"><i class="i-Download text-18 mr-2"></i> Download</a>
                                <div>Total Data : <span class="text-25 text-danger"><?php echo e($data->total()); ?></span></div>
                            </div>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Tanggal</th>
                                            <th scope="col">Nama Guide</th>
                                            <th scope="col">Jenis Pembayaran</th>
                                            <th scope="col">Bank Akun</th>
                                            <th scope="col">Nomor Akun Bank</th>
                                            <th scope="col">Nama Akun Bank</th>
                                            <th scope="col">Total</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($data->firstItem() + $key); ?></th>
                                                <td><?php echo e($item->created_at_display); ?></td>
                                                <td><?php echo e($item->guide->name); ?></td>
                                                <td><?php echo e($item->payment_type); ?></td>
                                                <td><?php echo e($item->bank_name); ?></td>
                                                <td><?php echo e($item->bank_account_number); ?></td>
                                                <td><?php echo e($item->bank_account_name); ?></td>
                                                <td><?php echo e($item->total_display); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-md-12 mt-5 text-center">
                                <?php echo e($data->appends($_GET)->links()); ?>

                            </div>
                        <?php else: ?> 
                            <div class="py-4">
                                <div class="text-center mb-2">Tidak ada hasil yang ditemukan</div>
                            </div>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
<script src="<?php echo e(asset('assets/js/tooltip.script.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/vendor/sweetalert2.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Job\DMedia\wahana\resources\views/pages/reports/fee-transfer.blade.php ENDPATH**/ ?>