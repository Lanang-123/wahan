<?php $__env->startSection('page-css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/styles/vendor/sweetalert2.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card text-left">
                <form action="<?php echo e(route('ticket-list')); ?>" method="get">
                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-6"><h4>Tiket</h4></div>
                            <?php if(count($data) > 0): ?>
                                <div class="col-md-6 text-right">
                                    <a href="<?php echo e(route('new-ticket')); ?>" class="btn btn-sm btn-info">
                                        <i class="h6 nav-icon i-Add mr-1 "></i>
                                        Tambah
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div>
                            <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>
    
                            <?php if($message = Session::get('error')): ?>
                                <div class="alert alert-danger alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <h5><i class="i-Filter-2 mr-2"></i>Filter</h5>
                            </div>
                            <div class="row col-md-12">
                                <div class="col-md-3 mb-3">
                                    <label>Status</label>
                                    <div class="input-group">
                                        <select class="js-autocomplete form-control" name="status" data-selected="<?php echo e($status); ?>" value="<?php echo e($status); ?>">
                                            <option value="">-- Semua status --</option>
                                            <?php $__currentLoopData = $ticketStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item); ?>" <?php echo e(($item == $status)? 'selected': ''); ?>><?php echo e(\Str::title($item)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2 form-group mb-3">
                                    <label>Kode tiket</label>
                                    <div class="input-group mt-1">
                                        <input type="text" name="code" value="<?php echo e($code); ?>" class="form-control" placeholder="Masukkan kode tiket" autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-md-2 mb-3 d-flex align-items-center">
                                    <button type="submit" class="btn btn-danger" >Filter</button>
                                </div>
                                <div class="col-md-4">
                                    <div class="card">
                                        <div class="card-body text-center">
                                            <p class="text-primary text-24 line-height-1 mb-2"><span class="text-12 mr-2">Total Data:</span><span><?php echo e($data->total()); ?></span></p>
                                            <div>
                                                <a href="<?php echo e(route('delete-expired-ticket')); ?>" class="btn btn-danger" >Hapus tiket kadaluarsa</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php if(count($data) > 0): ?>
                        
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">QR Code</th>
                                            <th scope="col">Code</th>
                                            <th scope="col">Ticket type</th>
                                            <th scope="col">Status</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                                            <tr>
                                                <th scope="row"><?php echo e($data->firstItem() + $key); ?></th>
                                                <td><?php echo QrCode::size(50)->generate($item->code);; ?></td>
                                                <td><?php echo e($item->code); ?></td>
                                                <td><?php echo e($item->ticket_type_name); ?></td>
                                                <td><?php echo e($item->status_display); ?></td>
                                                
                                                
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-md-12 mt-5 text-center">
                                <?php echo e($data->appends($_GET)->links()); ?>

                            </div>
                        <?php else: ?> 
                            <div class="py-4">
                                <div class="text-center mb-2">Tidak ada hasil yang ditemukan</div>
                                <div class="text-center">
                                    <a href="<?php echo e(route('new-ticket')); ?>" class="btn btn-sm btn-info">
                                        <i class="h6 nav-icon i-Add mr-1 "></i>
                                        Tambah
                                    </a>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
<script src="<?php echo e(asset('assets/js/tooltip.script.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/vendor/sweetalert2.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Job\DMedia\wahana\resources\views/pages/tickets/index.blade.php ENDPATH**/ ?>