<?php $__env->startSection('page-css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/styles/vendor/sweetalert2.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card text-left">
                <form action="<?php echo e(route('report-parkings')); ?>" method="get">
                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <h5><i class="i-Filter-2 mr-2"></i>Filter</h5>
                            </div>
                            <div class="row col-md-12">
                                <div class="col-md-3 mb-3">
                                    <label>Dari tanggal</label>
                                    <div class="input-group">
                                        <input name="startDate" value="<?php echo e(!empty(old('startDate')) ? old('startDate') : $startDate); ?>" class="picker2 form-control form-control" placeholder="yyyy-mm-dd" >
                                        <div class="input-group-append">
                                            <button class="btn btn-info"  type="button">
                                                <i class="icon-regular i-Calendar-4"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label>Sampai tanggal</label>
                                    <div class="input-group">
                                        <input name="endDate" value="<?php echo e(!empty(old('endDate')) ? old('endDate') : $endDate); ?>" class="picker2 form-control form-control" placeholder="yyyy-mm-dd" >
                                        <div class="input-group-append">
                                            <button class="btn btn-info"  type="button">
                                                <i class="icon-regular i-Calendar-4"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label>Jenis Kendaraan</label>
                                    <div class="input-group">
                                        <select class="js-autocomplete form-control" name="car_type_id" data-selected="<?php echo e($car_type_id); ?>" value="<?php echo e($car_type_id); ?>">
                                            <option value="">-- Semua jenis kendaraan --</option>
                                            <?php $__currentLoopData = $car_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>" <?php echo e(($item->id == $car_type_id)? 'selected': ''); ?>><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2 mb-3 d-flex align-items-end">
                                    <button type="submit" class="btn btn-danger" >Filter</button>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6"><h4>Laporan Parkir</h4></div>
                        </div>
                        <div>
                            <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>

                            <?php if($message = Session::get('error')): ?>
                                <div class="alert alert-danger alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php if(count($data) > 0): ?>
                            <div class="d-md-flex mb-3 justify-content-between">
                                <a href="<?php echo e(route('report-parkings', ['download' => true, 'startDate' => $startDate, 'endDate' => $endDate, 'car_type_id' => $car_type_id])); ?>" class="btn btn-success"><i class="i-Download text-18 mr-2"></i> Download</a>
                                <div>Total Data : <span class="text-25 text-danger"><?php echo e($data->total()); ?></span></div>
                            </div>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Tanggal</th>
                                            <th scope="col">Nomor</th>
                                            <th scope="col">Jenis Kendaraan</th>
                                            <th scope="col">Nomor Polisi</th>
                                            <th scope="col">Jumlah Penumpang</th>
                                            <th scope="col">Negara</th>
                                            <th scope="col">Driver/Guide</th>
                                            <th scope="col">Waktu Parkir</th>
                                            <th scope="col">Waktu Transaksi</th>
                                            <th scope="col">Durasi</th>
                                            <th scope="col">Harga</th>
                                            <th scope="col">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($data->firstItem() + $key); ?></th>
                                                <td><?php echo e($item->created_at_display); ?></td>
                                                <td><?php echo e($item->checkin_number); ?></td>
                                                <td><?php echo e($item->carType->name); ?></td>
                                                <td><?php echo e($item->police_number); ?></td>
                                                <td><?php echo e($item->total_passengers); ?></td>
                                                <td><?php echo e($item->country); ?></td>
                                                <td>
                                                    <?php if($item->is_fee): ?>
                                                    Ya
                                                    <?php else: ?>
                                                    Tidak
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($item->time_parking); ?></td>
                                                <td><?php echo e($item->transaction_time); ?></td>
                                                <td><?php echo e($item->duration_display); ?></td>
                                                <td><?php echo e($item->carType->price_display); ?></td>
                                                <td>
                                                    <?php if(Auth::user()->role_id == 0): ?>
                                                        <a class="btn btn-success" href="<?php echo e(route('print-parking', ['id' => $item->id])); ?>">
                                                            Detail
                                                        </a>
                                                    <?php else: ?>
                                                    <button class="btn btn-success" disabled="disabled">Detail</button>
                                                    <?php endif; ?>
                                                </td>
                                                        
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-md-12 mt-5 text-center">
                                <?php echo e($data->appends($_GET)->links()); ?>

                            </div>
                        <?php else: ?> 
                            <div class="py-4">
                                <div class="text-center mb-2">Tidak ada hasil yang ditemukan</div>
                            </div>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
<script src="<?php echo e(asset('assets/js/tooltip.script.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/vendor/sweetalert2.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp3\htdocs\PASSS\wahana\resources\views/pages/reports/parking.blade.php ENDPATH**/ ?>