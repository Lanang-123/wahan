<?php $__env->startSection('main-content'); ?>
    <?php
        $helper = new \App\Helper\Helper;
    ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <?php if($item): ?>
                    <form action="<?php echo e(route('update-user', ['uuid' => $item['uuid']])); ?>" method="post">
                    <input type="hidden" name="id" value="<?php echo e($item->id); ?>">    
                <?php else: ?>
                    <form action="<?php echo e(route('create-user')); ?>" method="post">
                <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="card-title mb-3"><?php echo e(($item) ? 'Edit' : 'Tambah'); ?> Pengguna</div>
                        <div class="separator-breadcrumb border-top"></div>
                        <div>
                            <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>
    
                            <?php if($message = Session::get('error')): ?>
                                <div class="alert alert-danger alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>
                        </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="firstName1">Nama</label>
                                        <input type="text" name="name" value="<?php echo e(!empty(old('name')) ? old('name') : (($item) ? $item['name'] : '')); ?>" class="form-control" placeholder="Masukkan name">
                                        <?php if($errors->has('name')): ?>
                                            <small class="text-danger"><?php echo e($errors->first('name')); ?></small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="firstName1">Email</label>
                                        <input type="text" name="email" value="<?php echo e(!empty(old('email')) ? old('email') : (($item) ? $item['email'] : '')); ?>" class="form-control" placeholder="Masukkan email">
                                        <?php if($errors->has('email')): ?>
                                            <small class="text-danger"><?php echo e($errors->first('email')); ?></small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php if(!$item): ?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="firstName1">Password</label>
                                            <input type="password" name="password" value="<?php echo e(!empty(old('password')) ? old('password') : (($item) ? $item['password'] : '')); ?>" class="form-control" placeholder="Masukkan password">
                                            <?php if($errors->has('password')): ?>
                                                <small class="text-danger"><?php echo e($errors->first('password')); ?></small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="firstName1">Konfirmasi Password</label>
                                            <input type="password" name="password_confirmation" value="<?php echo e(!empty(old('password_confirmation')) ? old('password_confirmation') : (($item) ? $item['password_confirmation'] : '')); ?>" class="form-control" placeholder="Masukkan konfirmasi password">
                                            <?php if($errors->has('password_confirmation')): ?>
                                                <small class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="firstName1">Jabatan</label>
                                        <input type="text" name="job_position" value="<?php echo e(!empty(old('job_position')) ? old('job_position') : (($item) ? $item['job_position'] : '')); ?>" class="form-control" placeholder="Masukkan jabatan">
                                        <?php if($errors->has('job_position')): ?>
                                            <small class="text-danger"><?php echo e($errors->first('job_position')); ?></small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <?php if(($item AND $item->role_id == 0) OR !$helper->isSuperAdmin()): ?>
                                <input type="hidden" name="role_id" value="<?php echo e($item->role_id); ?>">
                                <input type="hidden" name="is_active" value="<?php echo e($item->is_active); ?>">
                            <?php else: ?>
                                <div class="row">
                                    <div class="col-md-6 form-group mb-3">
                                        <label for="firstName1">Role</label>
                                        <select class="form-control" name="role_id">
                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($option['id']); ?>" <?php echo e(!empty(old('role_id') AND old('role_id') == $option['id']) ? 'selected' : (($item AND $item['role_id'] == $option['id']) ? 'selected' : '')); ?>><?php echo e($option['name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('role_id')): ?>
                                            <small class="text-danger"><?php echo e($errors->first('role_id')); ?></small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 form-group mb-3">
                                        <label for="picker1">Status</label>
                                        <div>
                                            <label class="switch switch-success mr-3">
                                                <input type="checkbox" name="is_active" value="1" <?php echo e(!empty(old('is_active') AND old('is_active') == '1') ? 'checked' : (($item AND $item['is_active'] == 1) ? 'checked' : '')); ?>>
                                                <span class="slider"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="<?php echo e(route('user-list')); ?>" class="btn btn-outline-light">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp3\htdocs\PASSS\wahana\resources\views/pages/users/form.blade.php ENDPATH**/ ?>