<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <?php if($item): ?>
                    <form action="<?php echo e(route('update-role', ['uuid' => $item['uuid']])); ?>" method="post" autocomplete="off">
                    <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                <?php else: ?>
                    <form action="<?php echo e(route('create-role')); ?>" method="post" autocomplete="off">
                <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="card-title mb-3"><?php echo e(($item) ? 'Edit' : 'Tambah'); ?> Role</div>
                        <div class="separator-breadcrumb border-top"></div>
                        <div class="form-row">
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label>Nama</label>
                                    <input type="text" name="name" value="<?php echo e(!empty(old('name')) ? old('name') : (($item) ? $item['name'] : '')); ?>" class="form-control" id="firstName1" placeholder="Masukkan name">
                                    <?php if($errors->has('name')): ?>
                                        <small class="text-danger"><?php echo e($errors->first('name')); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="custom-separator"></div>
                        <div class="form-row">
                            <div class="col-md-12">
                                <h4>Akses</h4>
                            </div>

                            <div class="table-responsive">
                                <table class="table">
                                    <tr class="table-primary">
                                        <th width="200">Menu</th>
                                        <th>Item</th>
                                        <th class="text-right">Action</th>
                                    </tr>
                                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lv1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="table-success">
                                            <th>
                                                <label class="checkbox checkbox-outline-success mb-2 mr-4">
                                                    <input class="menu" data-child="<?php echo e($lv1['route_name']); ?>" type="checkbox" name="<?php echo e($lv1['route_name']); ?>" <?php echo e((in_array($lv1['route_name'], $havePermissions)) ? 'checked' : ''); ?>>
                                                    <span><?php echo e($lv1['name']); ?></span>
                                                    <span class="checkmark"></span>
                                                </label>
                                            </th>
                                            <th></th>
                                            <th></th>
                                        </tr>
                                        <?php if(count($lv1['child']) > 0): ?>
                                            <?php $__currentLoopData = $lv1['child']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lv2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td></td>
                                                    <td>
                                                        <label class="checkbox checkbox-outline-success mb-2 mr-4">
                                                            <input class="menu <?php echo e($lv1['route_name']); ?>" data-child="<?php echo e($lv2['route_name']); ?>" type="checkbox" name="<?php echo e($lv2['route_name']); ?>" <?php echo e((in_array($lv2['route_name'], $havePermissions)) ? 'checked' : ''); ?>>
                                                            <span><?php echo e($lv2['name']); ?></span>
                                                            <span class="checkmark"></span>
                                                        </label>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex justify-content-end">
                                                        <?php if(count($lv2['child']) > 0): ?>
                                                            <?php $__currentLoopData = $lv2['child']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lv3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <label class="checkbox checkbox-outline-success mb-2 mr-4">
                                                                    <input class="<?php echo e($lv1['route_name']); ?> <?php echo e($lv2['route_name']); ?>" type="checkbox" name="<?php echo e($lv3['route_name']); ?>" <?php echo e((in_array($lv3['route_name'], $havePermissions)) ? 'checked' : ''); ?>>
                                                                    <span><?php echo e($lv3['name']); ?></span>
                                                                    <span class="checkmark"></span>
                                                                </label>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                        <?php if($lv2['route_name'] == 'loan-verification-list'): ?>
                                                            <?php for($i = 1; $i <= $numberOfApprover; $i++): ?>
                                                                <label class="checkbox checkbox-outline-success mb-2 mr-4">
                                                                    <input class="<?php echo e($lv1['route_name']); ?> <?php echo e($lv2['route_name']); ?>" type="checkbox" name="process-loan-verification|reject-loan-verification|approve-loan-verification|approve-loan-verification|approver:<?php echo e($i); ?>" <?php echo e((in_array('process-loan-verification|reject-loan-verification|approve-loan-verification|approve-loan-verification|approver:'.$i, $havePermissions)) ? 'checked' : ''); ?>>
                                                                    <span>Approver <?php echo e($i); ?></span>
                                                                    <span class="checkmark"></span>
                                                                </label>
                                                            <?php endfor; ?>
                                                        <?php endif; ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="<?php echo e(route('role-list')); ?>" class="btn btn-outline-light">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u827505187/domains/tiketparkirdiamond.com/wahana/resources/views/pages/roles/form.blade.php ENDPATH**/ ?>