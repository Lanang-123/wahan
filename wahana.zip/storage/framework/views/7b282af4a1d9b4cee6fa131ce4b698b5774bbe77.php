<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,400i,600,700,800,900" rel="stylesheet">
    <link id="gull-theme" rel="stylesheet" href="<?php echo e(asset('assets/styles/css/themes/lite-blue.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>

<body>
    <div class="auth-layout-wrap p-3" style="background-image: url(<?php echo e(asset('assets/images/bg.jpeg')); ?>)">
        <div class="card col-md-4 o-hidden">
            <div class="row">
                <div class="col-md-12">
                    <div class="p-4">
                        <div class="auth-logo text-center mb-4">
                            <img src="<?php echo e(asset('assets/images/logo-large.png')); ?>" alt="">
                        </div>
                        <h1 class="mb-3 text-18">Sign In</h1>
                        <div>
                            <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>
    
                            <?php if($message = Session::get('error')): ?>
                                <div class="alert alert-danger alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>
                        </div>
                        <form action="<?php echo e(route('submit-sign-in')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-3">
                                <label for="firstName1">Email address</label>
                                <input type="text" name="email" value="" class="form-control" id="firstName1" placeholder="Enter your first name">
                            </div>

                            <div class="form-group mb-3">
                                <label for="firstName1">Password</label>
                                <input type="password" name="password" value="" class="form-control" id="firstName1" placeholder="Enter your first name">
                            </div>

                            

                            <button type="submit"  class="btn btn-primary btn-block mt-4">Sign In</button>

                        </form>

                        

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('assets/js/common-bundle-script.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
</body>

</html>
<?php /**PATH D:\Job\DMedia\wahana\resources\views/pages/auth/sign-in.blade.php ENDPATH**/ ?>