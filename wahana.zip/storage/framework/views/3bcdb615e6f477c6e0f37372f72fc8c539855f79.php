<?php $__env->startSection('main-content'); ?>
<div class="breadcrumb">
    <div>
        <h1>Halo, <?php echo e(\Auth::user()->name); ?></h1>
        <div class="text-muted mt-1"><?php echo e($currentDateDisplay); ?></div>
    </div>
</div>

<div class="separator-breadcrumb border-top"></div>

<form action="<?php echo e(route('dashboard')); ?>" method="get">
    <div class="row mb-3">
        <div class="col-md-12">
            <h5><i class="i-Filter-2 mr-2"></i>Filter</h5>
        </div>
        <div class="row col-md-12">
            <div class="col-md-3 mb-3">
                <label>Dari tanggal</label>
                <div class="input-group">
                    <input name="startDate" value="<?php echo e(!empty(old('startDate')) ? old('startDate') : $startDate); ?>" class="picker2 form-control form-control" placeholder="yyyy-mm-dd" >
                    <div class="input-group-append">
                        <button class="btn btn-info"  type="button">
                            <i class="icon-regular i-Calendar-4"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <label>Sampai tanggal</label>
                <div class="input-group">
                    <input name="endDate" value="<?php echo e(!empty(old('endDate')) ? old('endDate') : $endDate); ?>" class="picker2 form-control form-control" placeholder="yyyy-mm-dd" >
                    <div class="input-group-append">
                        <button class="btn btn-info"  type="button">
                            <i class="icon-regular i-Calendar-4"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div class="col-md-2 mb-3 d-flex align-items-end">
                <button type="submit" class="btn btn-danger" >Filter</button>
            </div>
        </div>
    </div>
</form>

<?php
    $totalIncome = 0;
?>

<div class="row">
    <!-- ICON BG -->
    <div class="col-md-12">
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-2 mb-2">
                        <div class="text-center d-sm-block">
                            <p class="text-muted mt-2 mb-2 text-16"><strong>Parkir</strong></p>
                            <div class="card-icon-bg card-icon-bg-primary">
                                <i class="i-Car"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-10">
                        <?php if($data['parkings'] AND count($data['parkings']) > 0): ?>
                            <div class="table-responsive">
                                <table class="table mb-0 ">
                                    <thead>
                                        <tr>
                                            <th scope="col">Jenis Kendaraan</th>
                                            <th scope="col" class="text-center">Total Kendaraan</th>
                                            <th scope="col" class="text-center">Total Penumpang</th>
                                            <th scope="col" class="text-right">Total Uang</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $totalParkingAmount = 0;
                                        ?>
                                        <?php $__currentLoopData = $data['parkings']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $totalParkingAmount += $item['price'];
                                            ?>
                                            <tr>
                                                <td><?php echo e($item['name']); ?></td>
                                                <td class="text-center"><?php echo e($item['total']); ?></td>
                                                <td class="text-center"><?php echo e($item['total_passengers']); ?></td>
                                                
                                                <td class="text-right"><?php echo e(\Helper::getAmountDisplay($item['price'])); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th colspan="3">Total penjualan dari parkir</th>
                                            <td class="text-right"><span class="text-16 text-success"><strong><?php echo e(\Helper::getAmountDisplay($totalParkingAmount)); ?></strong></span></td>
                                        </tr>
                                        <?php
                                            $totalIncome += $totalParkingAmount;
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="w-100 h-100 d-flex justify-content-center align-items-center">
                                <span class="text-mute">Belum ada kendaraan parkir</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-2 mb-2">
                        <div class="text-center">
                            <p class="text-muted mt-2 mb-2 text-16"><strong>Penjualan</strong></p>
                            <div class="card-icon-bg card-icon-bg-primary">
                                <i class="i-Bar-Chart"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-10 mb-2">
                        <?php if($data['sales'] AND count($data['sales']) > 0): ?>
                            <div class="table-responsive">
                                <table class="table mb-0">
                                    <thead>
                                        <tr>
                                            <th scope="col" class="text-center"></th>
                                            <th scope="col" class="text-center">Total Transaksi</th>
                                            <th scope="col" class="text-center">Total Item</th>
                                            
                                            <th scope="col" class="text-right">Total Penjualan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $totalSales = 0;
                                            $totalTransaction = 0;
                                            $totalItem = 0;
                                        ?>
                                        <?php $__currentLoopData = $data['sales']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $totalSales += $item['total_price'];
                                                $totalTransaction += $item['total_transaction'];
                                                $totalItem += $item['total_item'];
                                            ?>
                                            <tr>
                                                <td><?php echo e(($item['use_guide']) ? 'Dengan Guide': 'Tanpa Guide'); ?></td>
                                                <td class="text-center"><?php echo e($item['total_transaction']); ?></td>
                                                <td class="text-center"><?php echo e($item['total_item']); ?></td>
                                                
                                                <td class="text-right"><?php echo e(\Helper::getAmountDisplay($item['total_price'])); ?></td>
                                            </tr>
                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th>Total penjualan</th>
                                            <th class="text-center"><?php echo e($totalTransaction); ?></th>
                                            <th class="text-center"><?php echo e($totalItem); ?></th>
                                            <td class="text-right"><span class="text-16 text-success"><strong><?php echo e(\Helper::getAmountDisplay($totalSales)); ?></strong></span></td>
                                        </tr>
                                    </tbody>
                                    <?php
                                        $totalIncome += $totalSales;
                                    ?>
                                </table>
                                
                            </div>
                        <?php else: ?>
                            <div class="w-100 h-100 d-flex justify-content-center align-items-center">
                                <span class="text-mute">Belum ada penjualan</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-2 mb-2">
                        <div class="text-center">
                            <p class="text-muted mt-2 mb-2 text-16"><strong>Objek</strong></p>
                            <div class="card-icon-bg card-icon-bg-primary">
                                <i class="i-Japanese-Gate"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-10 mb-2">
                        <?php if($data['checkinObject']): ?>
                            <div class="table-responsive">
                                <table class="table mb-0">
                                    <thead>
                                        <tr>
                                            <th scope="col" class="text-center">Total Pengunjung</th>
                                            <th scope="col" class="text-center">Dengan Guide</th>
                                            <th scope="col" class="text-right">Total Fee</th>
                                            <th scope="col" class="text-right">Total Penjualan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="text-center"><?php echo e($data['checkinObject']['total']); ?></td>
                                            <td class="text-center"><?php echo e($data['checkinObject']['total_with_guide']); ?></td>
                                            <td class="text-right"><?php echo e(\Helper::getAmountDisplay($data['checkinObject']['amount_fee'])); ?></td>
                                            <td class="text-right"><?php echo e(\Helper::getAmountDisplay($data['checkinObject']['price'])); ?></td>
                                        </tr>
                                        <tr>
                                            <th colspan="3">Total penjualan dari Objek</th>
                                            <td class="text-right"><span class="text-16 text-success"><strong><?php echo e(\Helper::getAmountDisplay($data['checkinObject']['price'])); ?></strong></span></td>
                                        </tr>
                                        <tr>
                                            <th colspan="3">Total fee dari Objek</th>
                                            <td class="text-right"><span class="text-16 text-danger"><strong><?php echo e(\Helper::getAmountDisplay($data['checkinObject']['amount_fee'])); ?></strong></span></td>
                                        </tr>
                                    </tbody>
                                    
                                </table>
                                
                            </div>
                        <?php else: ?>
                            <div class="w-100 h-100 d-flex justify-content-center align-items-center">
                                <span class="text-mute">Belum ada pengunjung</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-2 mb-2">
                        <div class="text-center">
                            <p class="text-muted mt-2 mb-2 text-16"><strong>Wahana</strong></p>
                            <div class="card-icon-bg card-icon-bg-primary">
                                <i class="i-Laughing"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-10 mb-2">
                        <?php if($data['checkinRides'] AND count($data['checkinRides']) > 0): ?>
                            <div class="table-responsive">
                                <table class="table mb-0">
                                    <thead>
                                        <tr>
                                            <th scope="col">Nama Wahana</th>
                                            <th scope="col" class="text-center">Total Pengunjung</th>
                                            <th scope="col" class="text-center">Dengan Guide</th>
                                            <th scope="col" class="text-right">Total Fee</th>
                                            <th scope="col" class="text-right">Total Penjualan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $totalRideSales = 0;
                                            $totalRideFee = 0;
                                        ?>
                                        <?php $__currentLoopData = $data['checkinRides']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $totalRideSales += $item['price'];
                                            $totalRideFee += $item['amount_fee'];
                                        ?>
                                            <tr>
                                                <td><?php echo e($item['name']); ?></td>
                                                <td class="text-center"><?php echo e($item['total']); ?></td>
                                                <td class="text-center"><?php echo e($item['total_with_guide']); ?></td>
                                                <td class="text-right"><?php echo e(\Helper::getAmountDisplay($item['amount_fee'])); ?></td>
                                                <td class="text-right"><?php echo e(\Helper::getAmountDisplay($item['price'])); ?></td>
                                                
                                                
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th colspan="4">Total penjualan dari wahana</th>
                                            <td class="text-right"><span class="text-16 text-success"><strong><?php echo e(\Helper::getAmountDisplay($totalRideSales)); ?></strong></span></td>
                                        </tr>
                                        <tr>
                                            <th colspan="4">Total fee dari wahana</th>
                                            <td class="text-right"><span class="text-16 text-danger"><strong><?php echo e(\Helper::getAmountDisplay($totalRideFee)); ?></strong></span></td>
                                        </tr>
                                    </tbody>
                                    <?php
                                        $totalIncome += $totalRideSales;
                                    ?>
                                </table>
                                
                            </div>
                        <?php else: ?>
                            <div class="w-100 h-100 d-flex justify-content-center align-items-center">
                                <span class="text-mute">Belum ada pengunjung wahana</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4 col-md-6 col-sm-6">
        <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
            <div class="card-body">
                <i class="i-Money-2"></i>
                <div class="ml-4">
                    <p class="text-muted mt-2 mb-0">Total Penjualan</p>
                    <p class="text-primary text-24 line-height-1 mb-2 js-totalFeeTransfer"><?php echo e(\Helper::getAmountDisplay($totalIncome)); ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-4 col-md-6 col-sm-6">
        <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
            <div class="card-body">
                <i class="i-Money-Bag"></i>
                <div class="ml-4">
                    <p class="text-muted mt-2 mb-0">Total Sudah Transfer Fee</p>
                    <p class="text-danger text-24 line-height-1 mb-2 js-totalFeeTransfer"><?php echo e(\Helper::getAmountDisplay($data['totalFeeTransfer'])); ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-4 col-md-6 col-sm-6">
        <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
            <div class="card-body">
                <i class="i-Financial"></i>
                <div class="ml-4">
                    <p class="text-muted mt-2 mb-0">Total Uang Diterima</p>
                    <p class="text-success text-24 line-height-1 mb-2 js-totalProfit"><?php echo e(\Helper::getAmountDisplay(($totalIncome - $data['totalFeeTransfer']))); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
<script src="<?php echo e(asset('assets/js/vendor/echarts.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/es5/echart.options.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/es5/dashboard.v1.script.js')); ?>"></script>
<script>
    // getDashboard();
    // setInterval(() => {
    //     getDashboard()
    // }, 10000);
    
    function getDashboard(){
        var baseUrl = <?php echo json_encode(url('/')); ?>

        $.ajax({
            url: baseUrl + '/live-dashboard',
            method:'GET',
            dataType:'json',
            success:function(res){
                if (res) {
                    $('.js-totalCheckinObject').text(res.totalCheckinObject);
                    $('.js-totalCheckinRide').text(res.totalCheckinRide);
                    $('.js-totalFeeTransfer').text(res.totalFeeTransfer);
                    $('.js-totalParking').text(res.totalParking);
                    $('.js-totalPassenger').text(res.totalPassenger);
                    $('.js-totalTicketSales').text(res.totalTicketSales);
                    $('.js-totalVoucherSales').text(res.totalVoucherSales);
                    $('.js-totalProfit').text(res.totalProfit);
                }
            },
            error: function(res) {
                console.log('ERROR', res);
            }
        });
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp3\htdocs\PASSS\wahana\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>