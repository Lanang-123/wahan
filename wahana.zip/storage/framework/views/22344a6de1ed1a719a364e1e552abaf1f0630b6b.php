<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                
                <form class="form" action="<?php echo e(route('new-order-with-parking')); ?>" method="get">
                    
                    <div class="card-body">
                        <div class="card-title mb-3">Penjualan tiket/voucher</div>
                        <div class="separator-breadcrumb border-top"></div>
                        <div>
                            <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>
    
                            <?php if($message = Session::get('error')): ?>
                                <div class="alert alert-danger alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>
                        </div>
                            <div class="form-row">
                                
                                <div class="col-md-4 form-group mb-3">
                                    <label>Nomor Parkir</label>
                                    <div class="input-group">
                                        <input type="text" name="code" value="<?php echo e(!empty(old('code')) ? old('code') : ''); ?>" class="form-control js-init-focus" placeholder="Masukkan nomor parkir">
                                    </div>
                                    <?php if($errors->has('code')): ?>
                                        <small class="text-danger"><?php echo e($errors->first('code')); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Lanjut</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp3\htdocs\PASSS\wahana\resources\views/pages/orders/withParking/form-parking.blade.php ENDPATH**/ ?>