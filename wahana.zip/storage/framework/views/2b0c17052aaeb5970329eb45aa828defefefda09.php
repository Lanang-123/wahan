
<?php
    $helper = new \App\Helper\Helper;
?>
<div class="side-content-wrap">
    <div class="sidebar-left open rtl-ps-none" data-perfect-scrollbar data-suppress-scroll-x="true">
        <ul class="navigation-left">
            <li class="nav-item">
                <a class="nav-item-hold" href="<?php echo e(route('dashboard')); ?>">
                    <i class="nav-icon i-Home1"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
                <div class="triangle"></div>
            </li>
            <?php if($helper->canAccess('master-data')): ?>
                <li class="nav-item <?php echo e(request()->is('starter/*') ? 'active' : ''); ?>" data-item="starter">
                    <a class="nav-item-hold" href="#">
                        <i class="nav-icon i-Big-Data"></i>
                        <span class="nav-text">Master Data</span>
                    </a>
                    <div class="triangle"></div>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('transaction')): ?>
                <li class="nav-item " data-item="transaksi">
                    <a class="nav-item-hold" href="#">
                        <i class="nav-icon i-Dollar-Sign"></i>
                        <span class="nav-text">Transaksi</span>
                    </a>
                    <div class="triangle"></div>
                </li>
            <?php endif; ?>

            <?php if($helper->canAccess('report')): ?>
                <li class="nav-item <?php echo e(request()->is('starter/*') ? 'active' : ''); ?>" data-item="laporan">
                    <a class="nav-item-hold" href="#">
                        <i class="nav-icon i-Bar-Chart"></i>
                        <span class="nav-text">Laporan</span>
                    </a>
                    <div class="triangle"></div>
                </li>
            <?php endif; ?>

            <?php if(\Auth::user()->role_id == 0): ?>
                <li class="nav-item <?php echo e(request()->is('starter/*') ? 'active' : ''); ?>" data-item="settings">
                    <a class="nav-item-hold" href="#">
                        <i class="nav-icon i-Gear"></i>
                        <span class="nav-text">Pengaturan</span>
                    </a>
                    <div class="triangle"></div>
                </li>
            <?php endif; ?>

            
        </ul>
    </div>

    <div class="sidebar-left-secondary rtl-ps-none" data-perfect-scrollbar data-suppress-scroll-x="true">
        <!-- Submenu Dashboards -->
        <ul class="childNav" data-parent="starter">
            <?php if($helper->canAccess('ticket-type-list')): ?>
                <li class="nav-item ">
                    <a class="<?php echo e(Route::currentRouteName()=='ticket-type-list' ? 'open' : ''); ?>" href="<?php echo e(route('ticket-type-list')); ?>">
                        <i class="nav-icon i-Ticket"></i>
                        <span class="item-name">Jenis Tiket</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('ticket-list')): ?>
                <li class="nav-item ">
                    <a class="<?php echo e(Route::currentRouteName()=='ticket-list' ? 'open' : ''); ?>" href="<?php echo e(route('ticket-list')); ?>">
                        <i class="nav-icon i-Ticket"></i>
                        <span class="item-name">Tiket</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('car-type-list')): ?>
                <li class="nav-item ">
                    <a class="<?php echo e(Route::currentRouteName()=='car-type-list' ? 'open' : ''); ?>" href="<?php echo e(route('car-type-list')); ?>">
                        <i class="nav-icon i-Car"></i>
                        <span class="item-name">Jenis Kendaraan</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('ride-owner-list')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('ride-owner-list')); ?>" class="<?php echo e(Route::currentRouteName()=='ride-owner-list' ? 'open' : ''); ?>">
                        <i class="nav-icon i-Business-Man"></i>
                        <span class="item-name">Pemilik Wahana</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('ride-list')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('ride-list')); ?>" class="<?php echo e(Route::currentRouteName()=='ride-list' ? 'open' : ''); ?>">
                        <i class="nav-icon i-Landscape1"></i>
                        <span class="item-name">Wahana</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('guide-list')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('guide-list')); ?>" class="<?php echo e(Route::currentRouteName()=='guide-list' ? 'open' : ''); ?>">
                        <i class="nav-icon i-Boy"></i>
                        <span class="item-name">Guide</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('voucher-list')): ?>
                <li class="nav-item">
                    <a class="<?php echo e(Route::currentRouteName()=='voucher-list' ? 'open' : ''); ?>" href="<?php echo e(route('voucher-list')); ?>">
                        <i class="nav-icon i-Tag-4"></i>
                        <span class="item-name">Voucher</span>
                    </a>
                </li>
            <?php endif; ?>
        </ul>

        <ul class="childNav" data-parent="transaksi">
            <?php if($helper->canAccess('print-list')): ?>
                <li class="nav-item ">
                    <a class="<?php echo e(Route::currentRouteName()=='print-list' ? 'open' : ''); ?>" href="<?php echo e(route('print-list')); ?>">
                        <i class="nav-icon i-Fax"></i>
                        <span class="item-name">Cetak Tiket/Voucher</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('handover-list')): ?>
                <li class="nav-item ">
                    <a class="<?php echo e(Route::currentRouteName()=='handover-list' ? 'open' : ''); ?>" href="<?php echo e(route('handover-list')); ?>">
                        <i class="nav-icon i-Check"></i>
                        <span class="item-name">Serah Terima Tiket/Voucher</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('new-parking')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('new-parking')); ?>" class="<?php echo e(Route::currentRouteName()=='new-parking' ? 'open' : ''); ?>">
                        <i class="nav-icon i-Receipt-3"></i>
                        <span class="item-name">Check in Parkir</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('new-order')): ?>
                <li class="nav-item">
                    <a class="<?php echo e(Route::currentRouteName()=='new-order' ? 'open' : ''); ?>" href="<?php echo e(route('new-order')); ?>">
                        <i class="nav-icon i-Money-2"></i>
                        <span class="item-name">Penjualan Tiket/Voucher</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('new-order-with-parking')): ?>
                <li class="nav-item">
                    <a class="<?php echo e(Route::currentRouteName()=='new-order-with-parking' ? 'open' : ''); ?>" href="<?php echo e(route('new-order-with-parking')); ?>">
                        <i class="nav-icon i-Money-2"></i>
                        <span class="item-name">Penjualan Tiket/Voucher dengan karcis parkir</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('new-object')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('new-object')); ?>" class="<?php echo e(Route::currentRouteName()=='new-object' ? 'open' : ''); ?>">
                        <i class="nav-icon i-Receipt-3"></i>
                        <span class="item-name">Check in Objek</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('new-checkin-ride')): ?>
                <li class="nav-item">
                    <a class="<?php echo e(Route::currentRouteName()=='new-checkin-ride' ? 'open' : ''); ?>" href="<?php echo e(route('new-checkin-ride')); ?>">
                        <i class="nav-icon i-Receipt-3"></i>
                        <span class="item-name">Check in Wahana</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('transfer-fee-list')): ?>
                <li class="nav-item">
                    <a class="<?php echo e(Route::currentRouteName()=='transfer-fee-list' ? 'open' : ''); ?>" href="<?php echo e(route('transfer-fee-list')); ?>">
                        <i class="nav-icon i-Money-Bag"></i>
                        <span class="item-name">Transfer Fee Guide</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('order-list')): ?>
                <li class="nav-item">
                    <a class="<?php echo e(Route::currentRouteName()=='order-list' ? 'open' : ''); ?>" href="<?php echo e(route('order-list')); ?>">
                        <i class="nav-icon i-Fax"></i>
                        <span class="item-name">Batal/Cetak Penjualan</span>
                    </a>
                </li>
            <?php endif; ?>
            

        </ul>
        <ul class="childNav" data-parent="laporan">
            <?php if($helper->canAccess('report-tickets')): ?>
                <li class="nav-item">
                    <a class="<?php echo e(Route::currentRouteName()=='report-tickets' ? 'open' : ''); ?>" href="<?php echo e(route('report-tickets')); ?>">
                        <i class="nav-icon i-Ticket"></i>
                        <span class="item-name">Tiket</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('report-vouchers')): ?>
                <li class="nav-item">
                    <a class="<?php echo e(Route::currentRouteName()=='report-vouchers' ? 'open' : ''); ?>" href="<?php echo e(route('report-vouchers')); ?>">
                        <i class="nav-icon i-Tag-4"></i>
                        <span class="item-name">Voucher</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('report-object')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('report-object')); ?>" class="<?php echo e(Route::currentRouteName()=='report-object' ? 'open' : ''); ?>">
                        <i class="nav-icon i-Network"></i>
                        <span class="item-name">Kunjungan Objek</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('report-rides')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('report-rides')); ?>" class="<?php echo e(Route::currentRouteName()=='report-rides' ? 'open' : ''); ?>">
                        <i class="nav-icon i-Network"></i>
                        <span class="item-name">Kunjungan Wahana</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('report-parkings')): ?>
                <li class="nav-item ">
                    <a class="<?php echo e(Route::currentRouteName()=='report-parkings' ? 'open' : ''); ?>" href="<?php echo e(route('report-parkings')); ?>">
                        <i class="nav-icon i-Car-3"></i>
                        <span class="item-name">Parkir</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('report-fee-transfers')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('report-fee-transfers')); ?>" class="<?php echo e(Route::currentRouteName()=='report-fee-transfers' ? 'open' : ''); ?>">
                        <i class="nav-icon i-Money-Bag"></i>
                        <span class="item-name">Fee Guide</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('report-sales')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('report-sales')); ?>" class="<?php echo e(Route::currentRouteName()=='report-sales' ? 'open' : ''); ?>">
                        <i class="nav-icon i-Money-2"></i>
                        <span class="item-name">Penjualan</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('report-cancel-order')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('report-cancel-order')); ?>" class="<?php echo e(Route::currentRouteName()=='report-cancel-order' ? 'open' : ''); ?>">
                        <i class="nav-icon i-Close"></i>
                        <span class="item-name">Penjualan dibatalkan</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if($helper->canAccess('report-checkout')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('report-checkout')); ?>" class="<?php echo e(Route::currentRouteName()=='report-checkout' ? 'open' : ''); ?>">
                        <i class="nav-icon i-Money-2"></i>
                        <span class="item-name">Tiket/Voucher Keluar</span>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
        <ul class="childNav" data-parent="settings">
            <li class="nav-item ">
                <a href="<?php echo e(route('role-list')); ?>" class="<?php echo e(Route::currentRouteName()=='role-list' ? 'open' : ''); ?>">
                    <i class="nav-icon i-Medal-3"></i>
                    <span class="item-name">Role</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('user-list')); ?>" class="<?php echo e(Route::currentRouteName()=='user-list' ? 'open' : ''); ?>">
                    <i class="nav-icon i-MaleFemale"></i>
                    <span class="item-name">Pengguna</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('profil')); ?>" class="<?php echo e(Route::currentRouteName()=='profil' ? 'open' : ''); ?>">
                    <i class="nav-icon i-Administrator"></i>
                    <span class="item-name">Profil</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('ticket-expiration')); ?>" class="<?php echo e(Route::currentRouteName()=='ticket-expiration' ? 'open' : ''); ?>">
                    <i class="nav-icon i-Ticket"></i>
                    <span class="item-name">Kadaluarsa Tiket</span>
                </a>
            </li>
        </ul>
    </div>
    <div class="sidebar-overlay"></div>
</div>
<!--=============== Left side End ================--><?php /**PATH /home/u827505187/domains/tiketparkirdiamond.com/wahana/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>