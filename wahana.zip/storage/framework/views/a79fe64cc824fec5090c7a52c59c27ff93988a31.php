<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title mb-3 d-flex justify-content-between">
                        <span>Penjualan tiket/voucher</span>
                        <span><?php echo e($currentDate); ?></span>
                    </div>
                    <div class="separator-breadcrumb border-top"></div>
                    <div>
                        <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success alert-block">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong><?php echo e($message); ?></strong>
                            </div>
                        <?php endif; ?>

                        <?php if($message = Session::get('error')): ?>
                            <div class="alert alert-danger alert-block">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong><?php echo e($message); ?></strong>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php if($data): ?>
                    <div class="card mb-3">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <h5>Nomor Polisi: <strong><?php echo e($data->police_number); ?></strong></h5> 
                                    <h5>Total Penumpang: <strong><?php echo e($data->total_passengers); ?></strong></h5> 
                                    <h5>Menggunakan Driver: <strong>
                                        <?php if($data->is_fee): ?>
                                            Ya
                                        <?php else: ?>
                                            Tidak
                                        <?php endif; ?>
                                        </strong></h5> 
                                </div>
                                <div class="col-md-4">
                                    <h5>Nomor Polisi: <strong><?php echo e($data->police_number); ?></strong></h5> 
                                    <h5>Total Penumpang: <strong><?php echo e($data->total_passengers); ?></strong></h5> 
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                        <div id="orderForm" class="card mb-3" data-url=<?php echo e(url('orders/check-code')); ?> data-total-ticket=<?php echo e($data->total_passengers); ?>>
                            <div class="card-body">
                                <div class="form-row">
                                    <div class="col-md-4 ticket">
                                        <label for="picker1">Masukkan Kode</label>
                                        <input type="text" name="code" value="" class="form-control js-init-focus js-scan-with-parking" placeholder="Masukkan kode tiket" autocomplete="off">
                                    </div>
                                    <div class="col-md-8 d-flex align-items-end justify-content-end">
                                        <h4>Total Items: <strong><span class="total-item">0</span>/<?php echo e($data->total_passengers); ?></strong></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <form class="form" action="<?php echo e(route('create-order', ['parking_id' => $data->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php if($errors->has('orders')): ?>
                                <small class="text-danger"><?php echo e($errors->first('orders')); ?></small>
                            <?php endif; ?>
                            <div class="table-responsive">
                                <table id="cart" class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Jenis Produk</th>
                                            <th scope="col">Code</th>
                                            <th scope="col">Harga</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                            <div class="card">
                                <div class="card-body text-center">
                                    <div class="mb-2">TOTAL</div>
                                    <div class="custom-separator"></div>
                                    <div><h2 class="text-success">Rp <span class="total-price">0</span></h2></div>
                                </div>
                            </div>
                            <div class="custom-separator"></div>
                            <div class="form-row">
                                <div class="col-md-12 form-group mb-3">
                                    <label for="picker1">Menggunakan guide?</label>
                                    <div>
                                        <label class="switch switch-success mr-3">
                                            <input type="checkbox" name="use_guide" <?php echo e(!empty(old('use_guide') AND old('use_guide') == '1') ? 'checked' : ''); ?>>
                                            <span class="slider"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="js-guide col-md-4 form-group mb-3" style="display: none">
                                    <label for="picker1">Guide</label>
                                    <select class="js-autocomplete2 form-control" data-json="<?php echo e(json_encode($guides)); ?>" data-selected="<?php echo e(!empty(old('guide_id')) ? old('guide_id') : ''); ?>" name="guide_id" value="<?php echo e(!empty(old('guide_id')) ? old('guide_id') : ''); ?>" >
                                        <?php $__currentLoopData = $guides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($guide['id']); ?>"><?php echo e($guide['member_number']); ?> - <?php echo e($guide['name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('guide_id')): ?>
                                        <small class="text-danger"><?php echo e($errors->first('guide_id')); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="custom-separator"></div>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </form>
                        
                        
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Job\DMedia\wahana\resources\views/pages/orders/withParking/form.blade.php ENDPATH**/ ?>