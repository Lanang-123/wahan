<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                
                <form class="form" action="<?php echo e(route('create-parking')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="card-title mb-3">Check in parkir</div>
                        <div class="separator-breadcrumb border-top"></div>
                        <div>
                            <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>
    
                            <?php if($message = Session::get('error')): ?>
                                <div class="alert alert-danger alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>
                        </div>
                            <div class="form-row">
                                <div class="col-md-12 form-group mb-3">
                                    <label for="picker1">Jenis kendaraan</label>

                                    <div class="ul-form__radio-inline">
                                        <?php $__currentLoopData = $carTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $carType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class=" ul-radio__position radio radio-primary form-check-inline mr-4">
                                            <input class="js-car-type" data-json="<?php echo e(json_encode($carTypes)); ?>" type="radio" name="car_type_id" value="<?php echo e($carType['id']); ?>">
                                            <span class="ul-form__radio-font"><?php echo e($carType['name']); ?><div><?php echo e(number_format($carType['price'],0, ',', '.')); ?></div></span>
                                            <span class="checkmark"></span>
                                        </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <?php if($errors->has('car_type_id')): ?>
                                        <small class="text-danger"><?php echo e($errors->first('car_type_id')); ?></small>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-4 form-group mb-3">
                                            <label>Nomor Polisi</label>
                                            <div class="input-group">
                                                <input type="number" name="police_number" value="<?php echo e(!empty(old('police_number')) ? old('police_number') : ''); ?>" class="form-control" placeholder="Masukkan nomor polisi">
                                            </div>
                                            <?php if($errors->has('police_number')): ?>
                                                <small class="text-danger"><?php echo e($errors->first('police_number')); ?></small>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-4 form-group mb-3">
                                            <label for="firstName1">Jumlah penumpang</label>
                                            <input type="number" name="total_passengers" value="<?php echo e(!empty(old('total_passengers')) ? old('total_passengers') : ''); ?>" class="form-control" placeholder="Masukkan jumlah penumpang">
                                            <?php if($errors->has('total_passengers')): ?>
                                                <small class="text-danger"><?php echo e($errors->first('total_passengers')); ?></small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 form-group mb-3">
                                    <label for="picker1">Wisatawan</label>
                                    <div class="ul-form__radio-inline">
                                        <label class=" ul-radio__position radio radio-primary form-check-inline">
                                            <input type="radio" name="traveler_type" value="domestik" checked>
                                            <span class="ul-form__radio-font">Domestik</span>
                                            <span class="checkmark"></span>
                                        </label>
                                        <label class=" ul-radio__position radio radio-primary form-check-inline">
                                            <input type="radio" name="traveler_type" value="asing">
                                            <span class="ul-form__radio-font">Asing</span>
                                            <span class="checkmark"></span>
                                        </label>
                                    </div>
                                    <?php if($errors->has('traveler_type')): ?>
                                        <small class="text-danger"><?php echo e($errors->first('traveler_type')); ?></small>
                                    <?php endif; ?>
                                </div>
                                <div class="js-guide col-md-4 form-group mb-3">
                                    <label for="picker1">Asal negara</label>
                                    <select class="js-autocomplete2 form-control" data-json="<?php echo e(json_encode($countries)); ?>" data-selected="<?php echo e(!empty(old('country')) ? old('country') : ''); ?>" name="country" value="<?php echo e(!empty(old('country')) ? old('country') : ''); ?>" >
                                        <option value="">-- Pilih Asal Negara --</option>
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country); ?>"><?php echo e($country); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('country')): ?>
                                        <small class="text-danger"><?php echo e($errors->first('country')); ?></small>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-12 form-group mb-3">
                                    <label for="picker1">Menggunakan driver?</label>
                                    <div class="ul-form__radio-inline">
                                        <label class=" ul-radio__position radio radio-primary form-check-inline">
                                            <input type="radio" name="is_fee" value="1" checked>
                                            <span class="ul-form__radio-font">Ya</span>
                                            <span class="checkmark"></span>
                                        </label>
                                        <label class=" ul-radio__position radio radio-primary form-check-inline">
                                            <input type="radio" name="is_fee" value="0">
                                            <span class="ul-form__radio-font">Tidak</span>
                                            <span class="checkmark"></span>
                                        </label>
                                    </div>
                                    <?php if($errors->has('is_fee')): ?>
                                        <small class="text-danger"><?php echo e($errors->first('is_fee')); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="custom-separator"></div>
                            <div class="row">
                                <div class="col-md-4 ">
                                    <div>Total</div>
                                    <div class="text-success text-26 js-price">0</div>
                                </div>
                            </div>
                            
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp3\htdocs\PASSS\wahana\resources\views/pages/checkins/parking.blade.php ENDPATH**/ ?>