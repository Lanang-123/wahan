<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <form action="<?php echo e(route('update-profil')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="card-title mb-3">Profil</div>
                        <div class="separator-breadcrumb border-top"></div>
                        <div>
                            <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>
    
                            <?php if($message = Session::get('error')): ?>
                                <div class="alert alert-danger alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="form-row">
                            <div class="col-md-12">
                                <h5>Kabag</h5>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="firstName1">Nama</label>
                                    <input type="text" name="name" value="<?php echo e(!empty(old('name')) ? old('name') : $head_of_division->name); ?>" class="form-control" placeholder="Masukkan nama kepala bidang">
                                    <?php if($errors->has('name')): ?>
                                        <small class="text-danger"><?php echo e($errors->first('name')); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="firstName1">Umur</label>
                                    <div class="input-group">
                                        <input type="text" name="age" value="<?php echo e(!empty(old('age')) ? old('age') : $head_of_division->age); ?>" class="form-control" placeholder="Masukkan nama kepala bidang">
                                        <div class="input-group-append">
                                            <span class="input-group-text" id="basic-addon1">Tahun</span>
                                        </div>
                                    </div>
                                    <?php if($errors->has('age')): ?>
                                        <small class="text-danger"><?php echo e($errors->first('age')); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group mb-3">
                                    <label for="firstName1">Jabatan</label>
                                    <textarea class="form-control" name="position"><?php echo e(!empty(old('position')) ? old('position') : $head_of_division->position); ?></textarea>
                                    <?php if($errors->has('position')): ?>
                                        <small class="text-danger"><?php echo e($errors->first('position')); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group mb-3">
                                    <label for="firstName1">Alamat</label>
                                    <textarea class="form-control" name="address"><?php echo e(!empty(old('address')) ? old('address') : $head_of_division->address); ?></textarea>
                                    <?php if($errors->has('address')): ?>
                                        <small class="text-danger"><?php echo e($errors->first('address')); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="custom-separator"></div>
                        <div class="form-row">
                            <div class="col-md-12">
                                <h5>Ketua</h5>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="firstName1">Nama</label>
                                    <input type="text" name="head" value="<?php echo e(!empty(old('head')) ? old('head') : $head); ?>" class="form-control" id="firstName1" placeholder="Masukkan nama ketua">
                                    <?php if($errors->has('head')): ?>
                                        <small class="text-danger"><?php echo e($errors->first('head')); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="custom-separator"></div>
                        <div class="form-row">
                            <div class="col-md-12">
                                <h5>Kasir</h5>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="firstName1">Nama</label>
                                    <input type="text" name="cashier" value="<?php echo e(!empty(old('cashier')) ? old('cashier') : $cashier); ?>" class="form-control" id="firstName1" placeholder="Masukkan nama ketua">
                                    <?php if($errors->has('cashier')): ?>
                                        <small class="text-danger"><?php echo e($errors->first('cashier')); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u827505187/domains/tiketparkirdiamond.com/wahana/resources/views/pages/settings/profil.blade.php ENDPATH**/ ?>